Release Summary:

Jennic Part Number: JN-RD-6026
Description:        IEEE802.15.4 Wireless Gateway
Version:            v1.0
Date:               22nd May 2010

Package Content:

/JN-RD-6026-IEEE802-15-4-Wireless-Gateway_1V0
    readme.txt
    /DR1135_JN5148_Wireless_Gateway_1V1
        /BOM             - Bill of materials
        /Doc             - Reference Manual
        /Gerbers         - Gerber Data
        /Pads            - Source Files
        /Schematic       - Module schematics


Revision History:

v1.0   - Initial Revision


