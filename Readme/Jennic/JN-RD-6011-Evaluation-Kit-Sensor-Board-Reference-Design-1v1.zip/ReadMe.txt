Release Summary:

Jennic Part Number: JN-RD-6011
Description:        Evaluation Kit Sensor Board Reference Design
Version:            v1.0
Date:               18th February 2009

Package Content:

/JN-RD-6011 Evaluation Kit Sensor Board Reference Design 1V0
  readme.txt
    /DR1048-Sensor-Board-1v1
      /BOM             - Bill of materials
      /Schematic       - Board schematics
      /Doc             - Reference Manual


Revision History:

v1.0   - First release as a reference design, recommended component 
         values used for the power supply and RC network on ResetN pin
         have been changed to improve device reset.
         Replaces Schematic JN-SH-5008

Summary of Power Supply Component Changes:

Component	Old Value	New Value	Comments
------------------------------------------------------------------------------------
C1		220uF		10uF		No Change to part Size
C2		220uF		No Fit
C3		10nF		680pF
C4		100nF		100nF
C5		100uF		2.2uF		Low ESR type, nu change to part size

Summary of Reset Network Component Changes:

Component	Old Value	New Value	Comments
------------------------------------------------------------------------------------
R20		10K		18K		5% Tolerance
C11		100nF		470nF		Requires <25% tolerance