I've removed all the documentation as its inclusion caused the zip file to be larger than the maximum allowed on the forum.

The documentation can be downloaded from:

http://www.sics.se/~adam/uip/index.php/Documentation