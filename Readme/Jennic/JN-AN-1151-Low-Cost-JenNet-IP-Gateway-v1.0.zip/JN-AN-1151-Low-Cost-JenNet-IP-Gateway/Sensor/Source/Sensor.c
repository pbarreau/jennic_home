/****************************************************************************
 * $Rev::                   $: Revision of last commit
 * $Author::                $: Author of last commit
 * $Date::                  $: Date of last commit
 * $HeadURL:                $
 ****************************************************************************
 * This software is owned by Jennic and/or its supplier and is protected
 * under applicable copyright laws. All rights are reserved. We grant You,
 * and any third parties, a license to use this software solely and
 * exclusively on Jennic products. You, and any third parties must reproduce
 * the copyright and warranty notice and any other legend of ownership on each
 * copy or partial copy of the software.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS". JENNIC MAKES NO WARRANTIES, WHETHER
 * EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE,
 * ACCURACY OR LACK OF NEGLIGENCE. JENNIC SHALL NOT, IN ANY CIRCUMSTANCES,
 * BE LIABLE FOR ANY DAMAGES, INCLUDING, BUT NOT LIMITED TO, SPECIAL,
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON WHATSOEVER.
 *
 * Copyright Jennic Ltd 2010. All rights reserved
 ****************************************************************************/

/****************************************************************************/
/***        Include files                                                 ***/
/****************************************************************************/
#include <jendefs.h>
#include <string.h>
#include <Jenie.h>
#include <JPI.h>
#include "Utils.h"
#include "config.h"
#include <AppApi.h>
#include <JenNetApi.h>
#include <stdlib.h>
#include <string.h>
#include <LedControl.h>
#include <HtsDriver.h>
#include "adc.h"
#include "setup.h"

#include <sensordata.h>
#include <exceptionhandler.h>

/****************************************************************************/
/***        Macro Definitions                                             ***/
/****************************************************************************/
#define BUTTON_0_PIN                1 << 9
#define MAX_PARENT_POLL_ATTEMPTS        3
/****************************************************************************/
/***        Type Definitions                                              ***/
/****************************************************************************/

typedef enum
{
    E_STATE_IDLE,
    E_STATE_RUNNING,
    E_STATE_MEASURING_BATTERY,
    E_STATE_POLLING_PARENT
}teAppState;

typedef enum
{
    E_EVENT_NWK_STARTED,
    E_EVENT_POLL,
    E_EVENT_STACK_RESET,
    E_EVENT_ADC_COMPLETE,
    E_EVENT_POLL_COMPLETE
}teAppEvent;

typedef struct
{
    teAppState          eAppState;
    tsSensorData        sSensorData;
    tsSetup             sSetup;
    bool_t              bNwkJoined;
    bool_t              bSleepRequested;
    uint8               u8PollAttempts;
}tsAppData;

/****************************************************************************/
/***        Local Function Prototypes                                     ***/
/****************************************************************************/
PRIVATE void vBusException(uint32 *pu32SP);
PRIVATE void vAlignmentException(uint32 *pu32SP);
PRIVATE void vIllegalInstructionException(uint32 *pu32SP);
PRIVATE bool_t bScanSortCb(tsScanElement *pasScanResult, uint8 u8ScanListSize, uint8 *pau8ScanListOrder);
PRIVATE void vSetState(teAppState eNewState);
PRIVATE void vProcessEvent(teAppEvent eEvent, void *pvParam);
PRIVATE void vSleep(uint16 u16Periodms);
/****************************************************************************/
/***        Exported Variables                                            ***/
/****************************************************************************/

/****************************************************************************/
/***        Local Variables                                               ***/
/****************************************************************************/

PRIVATE tsAppData sAppData;

/* Version/build information. */
PRIVATE uint8 au8Version[] __attribute__ ((used))   = "Gateway Sensor (End Device) - v1.0.0";
PRIVATE uint8 au8BuildDate[] __attribute__ ((used)) = __DATE__;
PRIVATE uint8 au8BuildTime[] __attribute__ ((used)) = __TIME__;

/****************************************************************************
 *
 * NAME: gJenie_CbNetworkApplicationID
 *
 * DESCRIPTION:
 * Entry point for application from boot loader.
 * CALLED AT COLDSTART ONLY
 * Allows application to initialises network paramters before stack starts.
 *
 * RETURNS:
 * Nothing
 *
 ****************************************************************************/
PUBLIC void vJenie_CbConfigureNetwork(void)
{
	/* Install handlers for CPU exceptions */
	vInstallExceptionHandler(IRQ_BUS_ERROR, (uint32)vBusException);
	vInstallExceptionHandler(IRQ_ALIGNMENT_ERROR, (uint32)vAlignmentException);
	vInstallExceptionHandler(IRQ_ILLEGAL_INSTRUCTION_ERROR, (uint32)vIllegalInstructionException);

	/* Initialise LED's used to display application status */
	vLedInitRfd();
	vLedControl(0,0);
	vLedControl(1,0);

	sAppData.bNwkJoined = FALSE;
	sAppData.sSensorData.u32NwkReJoinAttempts = 0;

	/* Register callback that will be used to decide which parent to join */
	vApi_RegScanSortCallback(bScanSortCb);

	/* Configure stack parameters */
	gJenie_NetworkApplicationID     = NETWORK_ID;
	gJenie_ScanChannels             = CHANNEL_SCAN_MASK;
	gJenie_MaxFailedPkts            = 5;
	gJenie_RoutingEnabled           = FALSE;
	gJenie_EndDevicePingInterval    = 0;
	gJenie_EndDeviceScanSleep       = 30000;    /* Units of 100ms */
	gJenie_EndDevicePollPeriod      = 0;        /* Use manual polling */
	gJenie_RecoverFromJpdm          = FALSE;

}

/****************************************************************************
 *
 * NAME: vJenie_CbInit
 *
 * DESCRIPTION:
 * Entry point for application after stack init.
 * Called after stack has initialised. Whether warm or cold start
 *
 * RETURNS:
 * Nothing
 *
 ****************************************************************************/
PUBLIC void vJenie_CbInit(bool_t bWarmStart)
{
	teJenieStatusCode eResult;
    /* Initialise utilities */
    vUtils_Init();
    /* Not yet ready to sleep! */
    sAppData.bSleepRequested = FALSE;

    /* Read SW1 on sensor board */
	if ((u32AHI_DioReadInput() & BUTTON_0_PIN) == 0)
	{
		/* Display the setup menu, this function does not return. */
		vSetup_Task(au8Version, au8BuildDate, au8BuildTime);
		/* Restart the JN5148 */
		vAHI_SwReset();
	}

    if (bWarmStart)
    {
        /* Set up the temperature/humidity sensor */
        vHTSreset();

        /* Setup ADC redy to measure battery voltage */
        vADC_Init();

        if (sAppData.bNwkJoined)
        {
            /* Turn on LED1 to show we are measuring/transmitting data */
            vLedInitRfd();
            vLedControl(0,0);
            vLedControl(1,1);

            /* Set state to running so state machine will start at correct point */
            vSetState(E_STATE_RUNNING);
        }
    }
    else
    {
        /* Turn on LED0 to show we are searching for a parent */
        vLedInitRfd();
        vLedControl(0,1);
        vLedControl(1,0);
    }
    /* Start the Jenie stack */
	eResult = eJenie_Start(E_JENIE_END_DEVICE);

	if(eResult != E_JENIE_SUCCESS)
	{
		/* Try again... */
		vJPI_SwReset();
	}
}

/****************************************************************************
 *
 * NAME: gJenie_CbMainFIRST
 *
 * DESCRIPTION:
 * Main user routine. This is called by the stack at regular intervals.
 *
 * RETURNS:
 * void
 *
 ****************************************************************************/
PUBLIC void vJenie_CbMain(void)
{
    eJenie_SetSleepPeriod(1000); /* 1 seconFIRSTd */
    /* regular watchdog reset */
    #ifdef WATCHDOG_ENABLED
       vAHI_WatchdogRestart();
    #endif

    if (!sAppData.bSleepRequested)
    {
	   vProcessEvent(E_EVENT_POLL, NULL);
    }
}
/****************************************************************************
 *
 * NAME: vJenie_CbStackMgmtEvent
 *
 * DESCRIPTION:
 * Used to receive stack management events
 *
 * PARAMETERS:      Name                    RW  Usage
 *                  *psStackMgmtEvent       R   Pointer to event structure
 *
 * RETURNS:
 * void
 *
 ****************************************************************************/
PUBLIC void vJenie_CbStackMgmtEvent(teEventType eEventType, void *pvEventPrim)
{
	if (!sAppData.bSleepRequested)
	{
		switch (eEventType)
		{
			case E_JENIE_POLL_CMPLT:
				vUtils_Debug("E_JENIE_POLL_CMPLT");
				vProcessEvent(E_EVENT_POLL_COMPLETE, pvEventPrim);
				break;

			case E_JENIE_PACKET_SENT:
				break;

			case E_JENIE_PACKET_FAILED:
				break;

			case E_JENIE_NETWORK_UP:
				vUtils_Debug("E_JENIE_NETWORK_UP");
				vProcessEvent(E_EVENT_NWK_STARTED, NULL);
				break;

			case E_JENIE_STACK_RESET:
				vUtils_Debug("E_JENIE_STACK_RESET");
				vProcessEvent(E_EVENT_STACK_RESET, NULL);
				break;

			case E_JENIE_CHILD_LEAVE:
				break;

			case E_JENIE_CHILD_REJECTED:

				break;

			default:

				break;
		}
	}
	else
	{
		if (eEventType == E_JENIE_STACK_RESET)
		{
			sAppData.bNwkJoined = FALSE;
			sAppData.eAppState  = E_STATE_IDLE;
		}
	}
}

/****************************************************************************
 *
 * NAME: vJenie_CbStackDataEvent
 *
 * DESCRIPTION:
 * Used to receive stack data events
 *
 * PARAMETERS:      Name                    RW  Usage
 *                  *psStackDataEvent       R   Pointer to data structure
 * RETURNS:
 * void
 *
 ****************************************************************************/
PUBLIC void vJenie_CbStackDataEvent(teEventType eEventType, void *pvEventPrim)
{
    switch(eEventType)
    {
    case E_JENIE_DATA:
        break;

    case E_JENIE_DATA_TO_SERVICE:
        break;

    case E_JENIE_DATA_ACK:
        break;

    case E_JENIE_DATA_TO_SERVICE_ACK:
        break;

    default:
        // Unknown data event type
        vUtils_DisplayMsg("!!Unknown Data Event!!", eEventType);
        break;
    }
}

/****************************************************************************
 *
 * NAME: vJenie_CbHwEvent
 *
 * DESCRIPTION:
 * Adds events to the hardware event queue.
 *
 * PARAMETERS:      Name            RW  Usage
 *                  u32Device       R   Peripheral responsible for interrupt e.g DIO
 *                  u32ItemBitmap   R   Source of interrupt e.g. DIO bit map
 *
 * RETURNS:
 * void
 *
 ****************************************************************************/
PUBLIC void vJenie_CbHwEvent(uint32 u32DeviceId,uint32 u32ItemBitmap)
{
	if (!sAppData.bSleepRequested)
	{
		if (u32DeviceId == E_AHI_DEVICE_ANALOGUE)
		{
			/* We have only enabled ADC so this is the only event that can occur */
			vProcessEvent(E_EVENT_ADC_COMPLETE, NULL);
		}
	}
}

/****************************************************************************
 *
 * NAME: vBusException
 *
 * DESCRIPTION:
 *
 * PARAMETERS:      Name            RW  Usage
 * None.
 *
 * RETURNS:
 * None.
 *
 * NOTES:
 * None.
 ****************************************************************************/
PRIVATE void vBusException(uint32 *pu32SP)
{
    vJPI_SwReset();
}

/****************************************************************************
 *
 * NAME: vAlignmentException
 *
 * DESCRIPTION:
 *
 * PARAMETERS:      Name            RW  Usage
 * None.
 *
 * RETURNS:
 * None.
 *
 * NOTES:
 * None.
 ****************************************************************************/
PRIVATE void vAlignmentException(uint32 *pu32SP)
{
    vJPI_SwReset();
}

/****************************************************************************
 *
 * NAME: vIllegalInstructionException
 *
 * DESCRIPTION:
 *
 * PARAMETERS:      Name            RW  Usage
 * None.
 *
 * RETURNS:
 * None.
 *
 * NOTES:
 * None.
 ****************************************************************************/
PRIVATE void vIllegalInstructionException(uint32 *pu32SP)
{
    vJPI_SwReset();
}
/****************************************************************************
 *
 * NAME: bScanSort
 *
 * DESCRIPTION: This function sort the results of an active scan performed
 *              by the stack (register it using the vApi_RegScanSortCallback
 *              function). The sort orders the scan results by RSSI, placing
 *              the potential parent with the strongest RSSI first in the list
 *              of devices to join.
 *
 * PARAMETERS:      Name               RW  Usage
 *                  pasScanResult      R   Pointer to the list of scan results
 *                  u8ScanListSize     R   Number of device in the scan list
 *                  pau8ScanListOrder  W   Pointer to list which deteremines
 *                                         the order in which the stack will
 *                                         attempt to join the devices found.
 *
 * RETURNS:
 * None.
 *
 * NOTES:
 * None.
 ****************************************************************************/
PRIVATE bool_t bScanSortCb(tsScanElement *pasScanResult, uint8 u8ScanListSize, uint8 *pau8ScanListOrder)
{
    uint8 i;
    bool_t bSwapped;
    /* Use a bubble sort to order the scan list (pau8ScanListOrder) by RSSI (strongest first) */
    do
    {
        bSwapped = FALSE;

        for (i = 0; i < u8ScanListSize; i++)
        {
            if (pasScanResult[pau8ScanListOrder[i]].u8LinkQuality < pasScanResult[pau8ScanListOrder[i+1]].u8LinkQuality)
            {
                /* Swap these two elements */
                uint8 u8Temp = pau8ScanListOrder[i];
                pau8ScanListOrder[i] = pau8ScanListOrder[i+1];
                pau8ScanListOrder[i+1] = u8Temp;
                bSwapped = TRUE;
            }
        }
    }
    while(bSwapped);
    /* Return control to the stack and allow it to continue with the scan/join process */
    return FALSE;
}
/****************************************************************************
 *
 * NAME: vSetState
 *
 * DESCRIPTION:
 *
 * PARAMETERS:      Name            RW  Usage
 * None.
 *
 * RETURNS:
 * None.
 *
 * NOTES:
 * None.
 ****************************************************************************/
PRIVATE void vSetState(teAppState eNewState)
{
    sAppData.eAppState = eNewState;
}
/****************************************************************************
 *
 * NAME: vProcessEvent
 *
 * DESCRIPTION:
 *
 * PARAMETERS:      Name            RW  Usage
 * None.
 *
 * RETURNS:
 * None.
 *
 * NOTES:
 * None.
 ****************************************************************************/
PRIVATE void vProcessEvent(teAppEvent eEvent, void *pvParam)
{
    switch (sAppData.eAppState)
    {
        case E_STATE_IDLE:
            if (eEvent == E_EVENT_NWK_STARTED)
            {
                sAppData.bNwkJoined = TRUE;

                vSetState(E_STATE_RUNNING);

                /* Load our configuration from flash */
                (void)bSetup_Read(&sAppData.sSetup);

                /* Set the parameters we are going to transmit */
                sAppData.sSensorData.u8Type = E_JENIE_END_DEVICE;
                sAppData.sSensorData.u8Floor = sAppData.sSetup.u8Floor;
                memcpy(sAppData.sSensorData.au8Name, sAppData.sSetup.au8Name, strlen((char *)sAppData.sSetup.au8Name));
                memcpy((uint8 *)&sAppData.sSensorData.u64Addr, (uint8 *)pvAppApiGetMacAddrLocation(), sizeof(uint64));

                /* We have now joined/re-joined the network so increment stats */
                sAppData.sSensorData.u32NwkReJoinAttempts++;

                /* Go to sleep until measurement is to be made */
                vSleep(sAppData.sSetup.u32PingPeriodms);
            }
            break;

        case E_STATE_RUNNING:
            if (eEvent == E_EVENT_STACK_RESET)
            {
                sAppData.bNwkJoined = FALSE;

                /* We can no longer communicate with our parent so stack will try to
                   rejoin network */
                vSetState(E_STATE_IDLE);
            }
            else if (eEvent == E_EVENT_POLL)
            {
                /* Start ADC based battery voltage measurement */
                vADC_StartConversion(E_AHI_ADC_SRC_VOLT);

                vSetState(E_STATE_MEASURING_BATTERY);
            }
            break;

        case E_STATE_MEASURING_BATTERY:
            if (eEvent == E_EVENT_ADC_COMPLETE)
            {
                /* Read battery voltage, now conversion is complete */
                sAppData.sSensorData.u16SupplyVoltage = u16ADC_ReadBattVolt();

                uint16 u16TempC;

                /* Read temperature */
                vHTSstartReadTemp();
                u16TempC = u16HTSreadTempResult();

                /* Convert temperature reading into degrees F = (C * 9/5) + 32 */
                sAppData.sSensorData.u8TemperatureF = (uint8)((uint16)((uint16)(u16TempC * 9U) / 5U) + 32);

				/* Transmit sensor data to coordinator (gateway) */
				(void)eJenie_SendData(0, (uint8 *)&sAppData.sSensorData, sizeof(tsSensorData), TXOPTION_SILENT);


                /* Now poll parent a couple of time in case it returns an error message */
                teJenieStatusCode ePollReqResult = eJenie_PollParent();
                sAppData.u8PollAttempts = 1;

                if (ePollReqResult != E_JENIE_DEFERRED)
                {
                    /* Could not poll parent for some reason, just sleep and try again next time */
                    vSleep(sAppData.sSetup.u32PingPeriodms);
                }
                else
                {
                    /* Poll request successful await response */
                    vSetState(E_STATE_POLLING_PARENT);
                }
            }
            else if (eEvent == E_EVENT_STACK_RESET)
            {
                sAppData.bNwkJoined = FALSE;

                /* We can no longer communicate with our parent so stack will try to
                   rejoin network */
                vSetState(E_STATE_IDLE);
            }
            break;

        case E_STATE_POLLING_PARENT:
            if (eEvent == E_EVENT_POLL_COMPLETE)
            {
                if (sAppData.u8PollAttempts++ < MAX_PARENT_POLL_ATTEMPTS)
                {
                    /* Poll parent again */
                    teJenieStatusCode ePollReqResult = eJenie_PollParent();

                    if (ePollReqResult != E_JENIE_DEFERRED)
                    {
                        /* Could not poll parent for some reason, just sleep and try again next time */
                        vSleep(sAppData.sSetup.u32PingPeriodms);
                    }
                }
                else
                {
                    /* Polling complete, return to sleep */
                    vSleep(sAppData.sSetup.u32PingPeriodms);
                }
            }
            else if (eEvent == E_EVENT_STACK_RESET)
            {
                sAppData.bNwkJoined = FALSE;

                /* We can no longer communicate with our parent so stack will try to
                   rejoin network */
                vSetState(E_STATE_IDLE);
            }
            break;

        default:

            break;
    }
}
/****************************************************************************
 *
 * NAME: vSleep
 *
 * DESCRIPTION:
 *
 * PARAMETERS: Name        RW  Usage
 *
 * RETURNS:
 * None.
 *
 * NOTES:
 * None.
 ****************************************************************************/
PRIVATE void vSleep(uint16 u16Periodms)
{
    /* Set all DIO to inputs with pullups on to reduce current consumption */
    vJPI_DioSetDirection(0x001FFFFFUL, 0);

    /* Turn off LEDs to show we are going into sleep mode */
    vLedControl(0, 0);
    vLedControl(1, 0);

    /* Ensure no events are processed after we request sleep */
    sAppData.bSleepRequested = TRUE;

    /* Set wake timer to wake us at next sampling point */
    (void)eJenie_SetSleepPeriod((uint32)u16Periodms);

    /* Put the device into sleep mode with RAM held */
    (void)eJenie_Sleep(E_JENIE_SLEEP_OSCON_RAMON);
}

/****************************************************************************/
/***        END OF FILE                                                   ***/
/****************************************************************************/
