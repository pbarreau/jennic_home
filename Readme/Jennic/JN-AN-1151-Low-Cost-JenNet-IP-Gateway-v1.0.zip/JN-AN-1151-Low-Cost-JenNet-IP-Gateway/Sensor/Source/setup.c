/****************************************************************************
 * $Rev::                   $: Revision of last commit
 * $Author::                $: Author of last commit
 * $Date::                  $: Date of last commit
 * $HeadURL:                $
 ****************************************************************************
 * This software is owned by Jennic and/or its supplier and is protected
 * under applicable copyright laws. All rights are reserved. We grant You,
 * and any third parties, a license to use this software solely and
 * exclusively on Jennic products. You, and any third parties must reproduce
 * the copyright and warranty notice and any other legend of ownership on each
 * copy or partial copy of the software.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS". JENNIC MAKES NO WARRANTIES, WHETHER
 * EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE,
 * ACCURACY OR LACK OF NEGLIGENCE. JENNIC SHALL NOT, IN ANY CIRCUMSTANCES,
 * BE LIABLE FOR ANY DAMAGES, INCLUDING, BUT NOT LIMITED TO, SPECIAL,
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON WHATSOEVER.
 *
 * Copyright Jennic Ltd 2010. All rights reserved
 ****************************************************************************/
/** @file
 *
 * @defgroup
 *
 */
/****************************************************************************/
/***        Include files                                                 ***/
/****************************************************************************/
#include <jendefs.h>
#include <JPI.h>
#include <stdlib.h>
#include <string.h>
#include <Utilities.h>
#include <config.h>
#include <serial.h>
#include <xsprintf.h>

#include "setup.h"

/****************************************************************************/
/***        Macro Definitions                                             ***/
/****************************************************************************/
/* This number is written to the first 4 bytes of flash sector 3 to signify
   that a custom setup is present */
#define FLASH_MAGIC_NUMBER              0x55AA3399UL

/* Default setup values */
#define SETUP_DEFAULT_FLOOR             0
#define SETUP_DEFAULT_PING_PERIOD_ms    5000
#define SETUP_DEFAULT_NAME              "NONE"

/* Define which DIO is to be used to indicate that setup mode should be
   initiated */
#if (SETUP_PORT == E_AHI_UART_0)
    #define SETUP_MODE_INPUT_DIO        4 /* DIO4 - CTS0 input */
#else
    #define SETUP_MODE_INPUT_DIO        17 /* DIO17 - CTS1 input */
#endif

#define SETUP_MODE_INPUT_MASK           (1UL << SETUP_MODE_INPUT_DIO)

/****************************************************************************/
/***        Type Definitions                                              ***/
/****************************************************************************/

/****************************************************************************/
/***        Local Function Prototypes                                     ***/
/****************************************************************************/
PRIVATE void vSetup_ClearScreen(void);
PRIVATE bool_t bSetup_SetDefault(void);
PRIVATE void vSetup_DisplayVersion(uint8 *pu8Version, uint8 *pu8BuildDate, uint8 *pu8BuildTime);
PRIVATE void vSetup_DisplayTagOptions(tsSetup *psSetup);

/****************************************************************************/
/***        Exported Variables                                            ***/
/****************************************************************************/

/****************************************************************************/
/***        Local Variables                                               ***/
/****************************************************************************/
PRIVATE tsSerialPortSetup sCOM1;
PRIVATE uint8 au8RxBuff[32];
PRIVATE uint8 au8TxBuff[1024];
PRIVATE uint8 au8SetupMsg[128];
PUBLIC uint8 u8Reset;

/****************************************************************************/
/***        Exported Functions                                            ***/
/****************************************************************************/
/****************************************************************************
 *
 * NAME:
 *
 * DESCRIPTION:
 *
 * RETURNS:
 *
 ****************************************************************************/
PUBLIC void vSetup_Task(uint8 *pu8Version, uint8 *pu8BuildDate, uint8 *pu8BuildTime)
{
    tsSetup sSetup;
    u8Reset = 0;

    /* Initialise serial port for configuration input/output */
    sCOM1.u8Port        = SETUP_PORT;
    sCOM1.u8DataBits    = 8;
    sCOM1.u8Parity      = 0;
    sCOM1.u8StopBits    = 1;
    sCOM1.u32BaudRate   = 115200;
    sCOM1.pu8RxBuff     = au8RxBuff;
    sCOM1.pu8TxBuff     = au8TxBuff;
    sCOM1.u16RxBuffLen  = sizeof(au8RxBuff);
    sCOM1.u16TxBuffLen  = sizeof(au8TxBuff);

    vSerial_Init(&sCOM1);

    /* Read current configuration so it can be displayed along with options */
    (void)bSetup_Read(&sSetup);

    while(u8Reset == 0)
    {
        /* Clear Screen */
        vSetup_ClearScreen();

        /* Display version information */
        vSetup_DisplayVersion(pu8Version, pu8BuildDate, pu8BuildTime);

        /* Display options */
        vSetup_DisplayTagOptions(&sSetup);
    }
}

/****************************************************************************
 *
 * NAME:
 *
 * DESCRIPTION:
 *
 * RETURNS:
 *
 ****************************************************************************/
PUBLIC bool_t bSetup_Read(tsSetup *psSetup)
{
    /* Check the first byte of flash sector 3, if it is not 0xff then a custom
       configuration must be present */
    if (bAHI_FlashInit(E_FL_CHIP_AUTO, NULL) == TRUE)
    {
        uint32 u32MagicNbr;

        if (bAHI_FullFlashRead(0x30000, sizeof(uint32), (uint8 *)&u32MagicNbr))
        {
            if (u32MagicNbr == FLASH_MAGIC_NUMBER)
            {
                if (bAHI_FullFlashRead(0x30000+sizeof(tsSetup), sizeof(tsSetup), (uint8 *)psSetup))
                {
                    /* Configuration present in flash and read successfully */
                    return TRUE;
                }
            }
        }
    }
    /* Setup not available in flash, or we failed to read it so just load
       the default values */
    psSetup->u32PingPeriodms    = SETUP_DEFAULT_PING_PERIOD_ms;
    psSetup->u8Floor            = SETUP_DEFAULT_FLOOR;
    memcpy(psSetup->au8Name, (uint8 *)SETUP_DEFAULT_NAME, strlen(SETUP_DEFAULT_NAME));
    psSetup->au8Name[strlen(SETUP_DEFAULT_NAME)] = 0; /* Add NULL to end string */

    return FALSE;
}

/****************************************************************************
 *
 * NAME:
 *
 * DESCRIPTION:
 *
 * RETURNS:
 *
 ****************************************************************************/
PUBLIC bool_t bSetup_Write(tsSetup *psSetup)
{
    bool_t bResult = FALSE;

    if (bAHI_FlashInit(E_FL_CHIP_AUTO, NULL) == TRUE)
    {
        /* Flash must be erased before we can write to it */
        if (bAHI_FlashEraseSector(3) == TRUE)
        {
            uint32 u32MagicNbr = FLASH_MAGIC_NUMBER;

            /* Write magic number to signify configuration data is present */
            if (bAHI_FullFlashProgram(0x30000, sizeof(uint32), (uint8 *)&u32MagicNbr))
            {
                /* Now write the configuration data into flash */
                if (bAHI_FullFlashProgram(0x30000+sizeof(tsSetup), sizeof(tsSetup), (uint8 *)psSetup))
                {
                    bResult = TRUE;
                }
            }
        }
    }
    return bResult;
}

/****************************************************************************
 *
 * NAME:
 *
 * DESCRIPTION:
 *
 * RETURNS:
 *
 ****************************************************************************/
PUBLIC bool_t bSetup_ModeSelected(void)
{
    bool_t bResult = TRUE;

    /* Check to see if configuration mode has been requested, indicated by
       the CTS0 line being pulled low */
    vJPI_DioSetDirection(SETUP_MODE_INPUT_MASK, 0);

    if (u32JPI_DioReadInput() & SETUP_MODE_INPUT_MASK)
    {
        bResult = FALSE;
    }
    return bResult;
}

/****************************************************************************/
/***        Local Functions                                               ***/
/****************************************************************************/
/****************************************************************************
 *
 * NAME:
 *
 * DESCRIPTION:
 *
 * RETURNS:
 *
 ****************************************************************************/
PRIVATE void vSetup_DisplayTagOptions(tsSetup *psSetup)
{
    volatile uint32 i;
    bool_t bDone = FALSE;
    uint8 au8StrInpBuff[16];

    /* Display available options and current configuration in [] brackets */
    xsprintf((char *)au8SetupMsg, "\n\r1. Set floor        [%d]", psSetup->u8Floor);
    vSerial_TxString(SETUP_PORT, au8SetupMsg);
    xsprintf((char *)au8SetupMsg, "\n\r2. Set ping period  [%dms]", psSetup->u32PingPeriodms);
    vSerial_TxString(SETUP_PORT, au8SetupMsg);
    xsprintf((char *)au8SetupMsg, "\n\r3. Set name         [%s]", psSetup->au8Name);
    vSerial_TxString(SETUP_PORT, au8SetupMsg);
    xsprintf((char *)au8SetupMsg, "\n\r4. Exit");
    vSerial_TxString(SETUP_PORT, au8SetupMsg);
    xsprintf((char *)au8SetupMsg, "\n\rR. Restore defaults");
    vSerial_TxString(SETUP_PORT, au8SetupMsg);
    xsprintf((char *)au8SetupMsg, "\n\rS. Save Settings");
    vSerial_TxString(SETUP_PORT, au8SetupMsg);
    xsprintf((char *)au8SetupMsg, "\n\r\n\rEnter option: ");
    vSerial_TxString(SETUP_PORT, au8SetupMsg);

    /* Capture user input */
    while (!bDone)
    {
        int16 i16Char;
        /* regular watchdog reset */
		#ifdef WATCHDOG_ENABLED
		   vAHI_WatchdogRestart();
		#endif

        if ((i16Char = i16Serial_RxChar(SETUP_PORT)) > 0)
        {
            switch((uint8)i16Char)
            {
                case '1':
                {
                    xsprintf((char *)au8SetupMsg, "\n\rEnter floor (0 to 9): ");
                    vSerial_TxString(SETUP_PORT, au8SetupMsg);

                    if (u32Serial_RxString(SETUP_PORT, au8StrInpBuff, sizeof(au8StrInpBuff)) == 2)
                    {
                        uint8 u8Floor = atoi((char *)au8StrInpBuff);

                        if (u8Floor < 10)
                        {
                            psSetup->u8Floor = u8Floor;
                        }
                    }
                    bDone = TRUE;
                }
                break;

                case '2':
                {
                    uint32 u32MaxPingPeriod = SENSOR_MAX_PING_PERIOD_ms;
                    uint32 u32MinPingPeriod = SENSOR_MIN_PING_PERIOD_ms;

                    xsprintf((char *)au8SetupMsg, "\n\rEnter ping period (%d to %dms): ", u32MinPingPeriod, u32MaxPingPeriod);
                    vSerial_TxString(SETUP_PORT, au8SetupMsg);

                    if (u32Serial_RxString(SETUP_PORT, au8StrInpBuff, sizeof(au8StrInpBuff)) <= 8)
                    {
                        uint32 u32PingPeriodms = atoi((char *)au8StrInpBuff);

                        if ((u32PingPeriodms >= SENSOR_MIN_PING_PERIOD_ms) && (u32PingPeriodms <= SENSOR_MAX_PING_PERIOD_ms))
                        {
                            psSetup->u32PingPeriodms = u32PingPeriodms;
                        }
                    }
                    bDone = TRUE;
                }
                break;

                case '3':
                {
                    xsprintf((char *)au8SetupMsg, "\n\rEnter name (14 chars max): ");
                    vSerial_TxString(SETUP_PORT, au8SetupMsg);

                    uint32 u32Len = u32Serial_RxString(SETUP_PORT, au8StrInpBuff, sizeof(au8StrInpBuff));

                    if (u32Len <= 15)
                    {
                        memcpy(psSetup->au8Name, au8StrInpBuff, u32Len);
                        psSetup->au8Name[u32Len - 1] = '\0';
                    }
                    bDone = TRUE;
                }
                break;
                case '4':
					/* Clear Screen */
					vSetup_ClearScreen();
					for (i = 0; i < 1000; i++);
					u8Reset = 1;
					bDone = TRUE;
					break;

                case 'r':
                case 'R':
                {
                    xsprintf((char *)au8SetupMsg, "\n\rRestoring Defaults.. ");
                    vSerial_TxString(SETUP_PORT, au8SetupMsg);

                    if (bSetup_SetDefault())
                    {
                        (void)bSetup_Read(psSetup);

                        xsprintf((char *)au8SetupMsg, "OK");
                        vSerial_TxString(SETUP_PORT, au8SetupMsg);
                    }
                    else
                    {
                        xsprintf((char *)au8SetupMsg, "ERROR");
                        vSerial_TxString(SETUP_PORT, au8SetupMsg);
                    }
                    /* Short delay so that message is displayed for a few seconds */
                    for (i = 0; i < 750000; i++);

                    bDone = TRUE;
                }
                break;

                case 's':
                case 'S':
                {
                    xsprintf((char *)au8SetupMsg, "\n\rSaving Settings.. ");
                    vSerial_TxString(SETUP_PORT, au8SetupMsg);

                    if (bSetup_Write(psSetup) == TRUE)
                    {
                        xsprintf((char *)au8SetupMsg, "OK");
                        vSerial_TxString(SETUP_PORT, au8SetupMsg);
                    }
                    else
                    {
                        xsprintf((char *)au8SetupMsg, "ERROR");
                        vSerial_TxString(SETUP_PORT, au8SetupMsg);
                    }
                    /* Short delay so that message is displayed for a few seconds */
                    for (i = 0; i < 750000; i++);

                    bDone = TRUE;
                }
                break;

                default:
                {
                    bDone = TRUE;
                }
                break;
            }
        }
    }
}

/****************************************************************************
 *
 * NAME:
 *
 * DESCRIPTION:
 *
 * RETURNS:
 *
 ****************************************************************************/
PRIVATE void vSetup_ClearScreen(void)
{
    xsprintf((char *)au8SetupMsg, "\x1b[2J");
    vSerial_TxString(SETUP_PORT, au8SetupMsg);

    xsprintf((char *)au8SetupMsg, "\x1b[H");
    vSerial_TxString(SETUP_PORT, au8SetupMsg);
}

/****************************************************************************
 *
 * NAME:
 *
 * DESCRIPTION:
 *
 * RETURNS:
 *
 ****************************************************************************/
PRIVATE void vSetup_DisplayVersion(uint8 *pu8Version, uint8 *pu8BuildDate, uint8 *pu8BuildTime)
{
    uint8 u8hPos, u8hLen;

    /* Work out the length of the string to be displayed */
    u8hLen = xsprintf((char *)au8SetupMsg, "%s - Build %s %s", pu8Version, pu8BuildDate, pu8BuildTime);
    u8hLen += 2; /* Add box sides */

    /* Draw top of box for menu screen header */
    xsprintf((char *)au8SetupMsg, "\xc9");
    vSerial_TxString(SETUP_PORT, au8SetupMsg);

    for (u8hPos = 0; u8hPos < u8hLen; u8hPos++)
    {
        xsprintf((char *)au8SetupMsg, "\xcd");
        vSerial_TxString(SETUP_PORT, au8SetupMsg);
    }
    xsprintf((char *)au8SetupMsg, "\xbb");
    vSerial_TxString(SETUP_PORT, au8SetupMsg);

    xsprintf((char *)au8SetupMsg, "\n\r\xba %s - Build %s %s \xba", pu8Version, pu8BuildDate, pu8BuildTime);
    vSerial_TxString(SETUP_PORT, au8SetupMsg);

    /* Draw bottom of box for menu screen */
    xsprintf((char *)au8SetupMsg, "\n\r\xc8");
    vSerial_TxString(SETUP_PORT, au8SetupMsg);

    for (u8hPos = 0; u8hPos < u8hLen; u8hPos++)
    {
        xsprintf((char *)au8SetupMsg, "\xcd");
        vSerial_TxString(SETUP_PORT, au8SetupMsg);
    }
    xsprintf((char *)au8SetupMsg, "\xbc");
    vSerial_TxString(SETUP_PORT, au8SetupMsg);

    xsprintf((char *)au8SetupMsg, "\n");
    vSerial_TxString(SETUP_PORT, au8SetupMsg);
}

/****************************************************************************
 *
 * NAME:
 *
 * DESCRIPTION:
 *
 * RETURNS:
 *
 ****************************************************************************/
PRIVATE bool_t bSetup_SetDefault(void)
{
    bool_t bResult = FALSE;

    /* Setting the config to default values simply involves erasing flash
       sector 3. The next time we read the config none will be found in flash
       and the default values will be used */
    if (bAHI_FlashInit(E_FL_CHIP_AUTO, NULL) == TRUE)
    {
        /* Flash must be erased before we can write to it */
        if (bAHI_FlashEraseSector(3) == TRUE)
        {
            bResult = TRUE;
        }
    }
    return bResult;
}

/****************************************************************************/
/***        END OF FILE                                                   ***/
/****************************************************************************/
