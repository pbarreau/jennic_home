
------------------------------------------------------------------------------
Release Summary:

Jennic Part Number:  JN-RD-6007 Intelligent Lighting Reference Design
Description:         Evaluation Package
Version:             1.5
Date:                31 MArch 2010
------------------------------------------------------------------------------

Description:

The following package is provided to allow customers to evaluate the performance 
of Jennic's Intelligent Lighting technology in a "real-world" environment.

Assuming the performance is acceptable, customers must complete and return the 
Spreadsheet Questionaire and Software License Agreement using the on-line 
tech-support system.

On the completion of the SLA Jennic will provide a Intelligent Lighting developer 
pack consisting of JN-RM-2047-Intelligent-Lighting Reference Manual, source code
and a set of codeblocks project files

Evaluation Package Contents:

/JN-RD-6007-Intelligent-Lighting-Evaluation

   /ReadMe.txt
   
   /Doc               
      /JN-WP-7001 Intelligent Steet Lighting.pdf     - Intelligent Lighting White Paper 
      /JN-UG-3067 Intelligent Lighting.pdf           - Intelligent Lighting User Guide
      /Intelligent-Lighting-SLA.pdf                  - Software License Agreement 
      /ApplicationRequirements-Bank-1v0.xls          - Generic Questionnaire
      
   /Binaries       	                             - Intelligent Lighting Binaries
      /Coordinator_JN5139.bin                        - Gateway Application
      /Coordinator_JN5148
      /Router_JN5139.bin                             - Streetlight Application
      /Router_JN5148.bin
      
   /Executables
      /JN_RD_6007_Intelligent_Lighting.exe           - PC Graphical User Interface
      
   /Gateway Commands                                 - Gateway control utilities
      /terminal.exe                                  - Br@y++ Terminal program
      /*.txt                                         - Command files
      .*.tsc                                         - MAcros for terminal.exe
                                                          

Revision History:

30 Oct 2009	v1.4	 Public release onto Website

31 Mar 2010	v2.0	 Added Support for JN5148